Contributing
------------

### Running the Tests

1. Make sure [nodejs](http://nodejs.org) is installed
2. Run `npm install -g browserify testling; npm i` from your command line
3. Run `npm test` from your command line and check the console
